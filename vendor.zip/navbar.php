  <header>
      <div class="container">
          <nav class="nav_bg">
              <div class="nav_container">
                  <ul class="nav_items">
                      <li class="nav_links"><a href="index.php">Home</a></li>
                      <li class="nav_links"><a href="about.php">About Us</a></li>
                      <li class="nav_links"><a href="services.php">Services</a></li>
                      <li class="nav_links"><a href="faq.php">FAQ'S</a></li>
                      <li class="nav_links"><a href="contact.php">Contact</a></li>
                      <div>
                          <a href="book.php"><button class="btn2">Book Now</button></a>
                      </div>
                  </ul>
                  <div class="mobile_nav">
                      <div class="mobile_logo">
                          <a href="index.php"><img src="src/images/grand_logo.png" alt="" /></a>
                      </div>
                      <div class="nav_btn">
                          <button id="open__nav-btn">
                              <i class="uil uil-bars"></i>
                          </button>
                          <button id="close__nav-btn">
                              <i class="uil uil-times"></i>
                          </button>
                      </div>
                  </div>
              </div>
          </nav>
      </div>
  </header>